import UIKit
import Firebase

class ChatViewController: UIViewController {

    /*----------Simple array to test cells and table view--------*/
    var messages : [Message] = [
    ]
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var messageTextfield: UITextField!
    
    let db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        title = "⚡️FlashChat"
        
        tableView.register(UINib(nibName: K.cellNibName, bundle: nil), forCellReuseIdentifier: K.cellIdentifier)
        
        /*-------To hide navigation bar --------*/
        navigationItem.hidesBackButton = true

        loadMessage()
        
    }
    
    func loadMessage() {
       
        db.collection(K.FStore.collectionName).order(by: K.FStore.dateField).addSnapshotListener { (querysnapshot, error) in
          
            self.messages = [ ]
            //if let e = error
            if error != nil{
                print("Their an issue of retrivign data")
            }else{
                if let snapshotDocuments = querysnapshot?.documents{
                    for doc in snapshotDocuments{
                        let data = doc.data()
                        if let messgeSender = data[K.FStore.senderField] as? String , let messageBody = data[K.FStore.bodyField] as? String {
                            
                            let newMessage = Message(sender: messgeSender, body: messageBody)
                            self.messages.append(newMessage)
                            DispatchQueue.main.async {
                                self.tableView.reloadData()
                                let indexpath = IndexPath(row: self.messages.count - 1, section: 0)
                                self.tableView.scrollToRow(at: indexpath, at: UITableView.ScrollPosition.top, animated: true)
                                
                            }
                        }
                    }
                }
            }
        }
        
        
    }
    /*----------------Here we made func for send button when pressed after write message it will sort message and sender on database -----*/
    @IBAction func sendPressed(_ sender: UIButton) {
        if let messageBody = messageTextfield.text , let messageSender = Auth.auth().currentUser?.email{
            
            db.collection(K.FStore.collectionName).addDocument(data: [K.FStore.senderField : messageSender , K.FStore.bodyField : messageBody, K.FStore.dateField : Date() .timeIntervalSince1970]) { (error) in
                if let e = error {
                    print("This is issue and saving data on firestore ,\(e)")
                }else{
                    print("Successfully Saved Data.")
                
                        self.messageTextfield.text = " "
                    
                }
            }
        }
        
    }
    
    /*-------That is logout button to logout from chatting screen to welcome screen --------*/
    
    // MARK
    @IBAction func logoutButton(_ sender: UIBarButtonItem) {
        
        do {
          try Auth.auth().signOut()
            
            navigationController?.popToRootViewController(animated: true)
            
        } catch let signOutError as NSError {
          print ("Error signing out: %@", signOutError)
        }
    }
}
/*----------------------Here call prop of table view and call some func -----------*/
/*---------------------Frist call func to return any message on messages array---------*/

// MARK

extension ChatViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    /*-------------------Here display messages in XIB file and call it by identifier-----------*/
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let message = messages[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: K.cellIdentifier, for: indexPath)
            /*--- His key of XIB file------*/
        as! MessageCell
        cell.Lable.text = message.body
        // This message from current user
        if message.sender == Auth.auth().currentUser?.email{
            
            cell.leftImageView.isHidden = true
            cell.rightImageView.isHidden = false
            cell.messageBubbal.backgroundColor = UIColor (named: K.BrandColors.lightPurple)
            cell.Lable.textColor = UIColor(named: K.BrandColors.purple)
            
        }
        // This message from another user
        else{
            cell.leftImageView.isHidden = false
            cell.rightImageView.isHidden = true
            cell.messageBubbal.backgroundColor = UIColor (named: K.BrandColors.purple)
            cell.Lable.textColor = UIColor(named: K.BrandColors.lightPurple)
            
        }
        return cell
    }
}
