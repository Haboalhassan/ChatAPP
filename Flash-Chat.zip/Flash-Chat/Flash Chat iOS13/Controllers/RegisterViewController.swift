//

import UIKit
import Firebase

class RegisterViewController: UIViewController {

    @IBOutlet weak var emailTextfield: UITextField!
    @IBOutlet weak var passwordTextfield: UITextField!
    
    /*--------- Here we made resgister process useign fire base method with clousier*/
    
    @IBAction func registerPressed(_ sender: UIButton) {
        
        if let email = emailTextfield.text , let password = passwordTextfield.text{
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            
            if let e = error {
                print(e.localizedDescription)
            }else{
                
                
                /*------------------- K.register returned to constant file keys --------------*/
                
                self.performSegue(withIdentifier: K.registerSegue, sender: self)
            }
            }
        }
        
    }
    
}
