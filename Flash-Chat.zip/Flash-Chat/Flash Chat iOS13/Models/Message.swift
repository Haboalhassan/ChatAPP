//
//  Message.swift
//  Flash Chat iOS13
//
//  Created by Hassan on 5/26/1441 AH.
//

import Foundation

struct Message {
    let sender :String
    let body:String
}
